---
title: "mg_mqtt_unsuback()"
decl_name: "mg_mqtt_unsuback"
symbol_kind: "func"
signature: |
  void mg_mqtt_unsuback(struct mg_connection *nc, uint16_t message_id);
---

Sends a UNSUBACK command with a given `message_id`. 

