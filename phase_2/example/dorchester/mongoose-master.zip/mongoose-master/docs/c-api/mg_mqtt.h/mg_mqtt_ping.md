---
title: "mg_mqtt_ping()"
decl_name: "mg_mqtt_ping"
symbol_kind: "func"
signature: |
  void mg_mqtt_ping(struct mg_connection *nc);
---

Sends a PINGREQ command. 

