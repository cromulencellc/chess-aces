Widgetset feature example
-------------------------

This is an example that illustrates how a Wt application can be used
as a widget that is embedded in another web site or application.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- the use of the `WServer::addEntryPoint()` API to configure an application
  as a widget set