Video feature example
---------------------

This is an example that illustrates the use of the `WVideo` API
for using the HTML built-in video support.

In most situations, the WMediaPlayer is more useful since it has a
unified look and feel for the HTML and Flash fall-back.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- the use of the `WVideo` and `WFlashPlayer` API.