Meadiaplayer feature example
----------------------------

This is an example that illustrates the use of the `WMediaPlayer` to
integrate video and audio in a Wt application.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- the use of the `WMediaPlayer` widget.