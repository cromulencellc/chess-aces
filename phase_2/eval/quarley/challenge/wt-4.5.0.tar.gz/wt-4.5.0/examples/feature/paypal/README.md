Paypal feature example
---------------------

For more information about the PayPal API see:
https://cms.paypal.com/us/cgi-bin/?cmd=_render-content&content_ID=developer/e_howto_api_ECGettingStarted

It illustrates the flow to use PayPalExpressCheckout:

How to run
----------

See the README in the parent directory.

Additional arguments: `-c wt_config.xml`

By default, the PayPal Developers Sandbox is used, but an actual PayPal
merchant account can be configured in the configuration file.

What it illustrates
-------------------

The use of many aspects of the `Wt::Payment::PayPal` API
