TechEmpower frameworks benchmark implementation
-----------------------------------------------

This example implements the TechEmpower framework benchmark tests for Wt.

How to run
----------

See the README in the parent directory.

Additional arguments to fit the benchmark requirements:

- `-c wt_config.xml`: config that disables logging
- `--accesslog=-`: disables access log
- `--no-compression`: disables zlib compression

What it illustrates
-------------------

How to implement a simple RESTful service in Wt using custom WResources.
