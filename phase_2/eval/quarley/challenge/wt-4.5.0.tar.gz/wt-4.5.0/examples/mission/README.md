Mission impossible example
--------------------------

This example illustrates the use of a WTimer to implement a simple
count-down sequence.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- the use of `WTimer`
