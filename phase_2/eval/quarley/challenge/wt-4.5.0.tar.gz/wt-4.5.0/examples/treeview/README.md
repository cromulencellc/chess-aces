Treeview example
----------------

The example illustrates the usage of a `WTreeView` to display data
managed by a `WStandardItemModel`.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- using a `WTreeView` with a `WStandardItemModel`