Hello-world example
-------------------

This example is a minimal Wt application. This example is covered as
part of the [Wt tutorial](http://www.webtoolkit.eu/wt/doc/tutorial/wt.html).

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

Basic concepts of Wt: the application concept, the use of widgets,
user input, and event handling.