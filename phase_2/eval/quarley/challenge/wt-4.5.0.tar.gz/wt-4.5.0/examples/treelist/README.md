treelist example
----------------

This example shows a naive implementation of a tree (as a hierarchy of
`TreeNode` objecs), which was an early version of the `WTreeNode` part
of the library.

This example is a bit dated since CSS3 now includes rounded corners
which are already broadly supported across browsers.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- stateless slot learning to implement client-side event handling