WebGL example
-------------

The example illustrates the usage of a `WGLWidget` to render 3D
directly in the browser. It renders the classic teapot.

How to run
----------

See the README in the parent directory.

What it illustrates
-------------------

- using `WebGL` in Wt using `WGLWidget`